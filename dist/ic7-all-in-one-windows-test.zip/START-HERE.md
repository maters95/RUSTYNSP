# All-in-one Windows iC-7 test kit

This kit contains the matching NSP DLL, resource-only NEX, unchanged supplied
map, GIF/MP4 samples, Qt setup scripts, and Windows emulator. Resourcefix,
startup media, and positioned GIF alert banners are combined.

This is experimental. Windows GUI operation and physical boot/alarm behavior
have not been verified. Start with the virtual device, with the physical dash
disconnected. Nothing in this kit automatically flashes hardware.

## 1. Prepare Windows

Extract the entire ZIP into a writable folder such as
`Downloads\IC7-All-In-One`. Do not run tools from inside the ZIP.

Prerequisites not redistributed in this kit:

- Your official complete Haltech NSP **1.48.5** installation.
- Python **3.11 or newer**, with the Python launcher installed.
- Internet for verified Qt downloads and emulator Python dependencies.
- 7-Zip, or Windows tar capable of reading the Qt 7z archives.
- A signed virtual serial/null-modem driver for connecting NSP to the emulator.
  HHD Virtual Serial Ports or signed com0com can provide a COM10/COM11 pair.
  Never disable driver signing or use the physical dash's port.

## 2. Create the separate test NSP copy

Close NSP and its dashboard renderers. In PowerShell, from the extracted kit:

```powershell
cd .\NSP-test-kit
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup-native-media.ps1 `
  -NspInstall 'C:\Program Files (x86)\Haltech\Nexus Software\Haltech NSP' `
  -Destination "$env:USERPROFILE\Downloads\NSP-native-media-alerts"
```

Adjust NspInstall if your official NSP is elsewhere. Destination must be NEW,
outside the official install. Setup verifies downloads, copies the installed
application, then installs the test DLL and required Qt add-ons. If setup
reports an error, stop and retain the full error; do not copy DLLs manually.

If you already created a test NSP copy from an earlier kit, rerun setup into
a NEW destination folder (or delete the old one first) so this DLL is used.

Launch `NSP.exe` from that NEW destination, not the official shortcut.
Open the included `NSP-test-kit\map\*.nexmap`. Save As a new test-map name.
Open its dashboard editor once so the matching native Qt add-ons are staged.
Close NSP and its dashboard renderer before starting the isolated renderer.
The map supplied in the kit is unchanged and is not preconfigured for alerts.

## 3. Connect the virtual device

Create a paired virtual connection, for example COM10 <-> COM11, in your signed
driver's configuration. COM10 is NSP-facing; COM11 is emulator-facing.

From `ic7-emulator`, run `start-workbench.cmd`. First launch creates its private
Python environment and installs dependencies. Accept the discovery setup only
for virtual COM10 if prompted; it may request administrator permission.
Select virtual COM11, NOT "Preview only", then click Start Session.
Always use a fresh Start Session for each test run (older sessions from earlier
kits rejected maps above 32 MB and caused the "importing maps" stall).
Leave NEX package empty for the initial protocol/media tests.
Leave the workbench running.

Reopen the NEW test NSP and connect to the simulated dash on COM10.
Its simulated serial is F1C700000001. Do not select a physical device.
Open your saved test map and apply/upload its settings and resources.
The supplied map is about 44 MB; allow a few minutes over a virtual COM port.
If upload still stops, NSP now shows the failing resource and byte offset.
Click Session Folder in the workbench and send `emulator.log` and
`protocol.jsonl` together with the NSP error text.
Opening a file alone is not a map upload: the emulator stays blank until NSP
writes dashboard component settings.

From a second terminal in `ic7-emulator`, run:

```powershell
.\start-stock-renderer.cmd
```

If dependency validation fails, open the map in the NEW NSP copy once to stage
the add-ons, close its renderer, then retry. The bridge uses the AppData
Haltech\Nexus runtime and requires DirectShow dsengine, not wmfengine alone.
Do not use the legacy -PatchedImages GIF-only override for MP4 testing.
Only one isolated stock renderer should run.

## 4. Test startup GIF and MP4

In NSP's existing splash selector import/select
`NSP-test-kit\samples\animated.gif`. The Splash Screen preview inside NSP
now animates GIFs; MP4 shows a "MP4 startup video" placeholder (it plays on
the dash). Save the test map and apply/upload.
Trigger NSP's Reboot action for the virtual dash.
Confirm moving GIF startup, then dashboard handoff within 3.3 seconds.
Repeat Reboot twice. Repeat with `samples\video.mp4`: moving, muted video,
then dashboard. Selecting a static image disables the animated overlay.
Close/reopen the saved map and repeat upload to verify persistence.

This animates the Qt/application stage. The physical dash's earliest kernel
logo stays static. The emulator does not execute a real kernel or bootloader.

## 5. Configure GIF alert banners and placement

There are three ways to open the alert banner editor in test NSP:

- On an alarm's settings page, click the "Banner GIF & position..." button
  shown below the Message setting.
- Right-click the alarm (Alarm 1, Alarm 2...) in the left tree and choose
  "Banner GIF & position...".
- Main menu item "Alert GIF banners and placement...".

The first two pre-select that alarm. Matching uses the exact, case-sensitive
alarm MESSAGE text (what the dash shows in the banner), not the alarm's name.
If an alarm has no Message text, set one first.
Choose GIF/image and import/select `samples\animated.gif`.
Drag the layout rectangle to move it; drag its bottom-right corner to resize.
Or enter X/Y/Width/Height numerically. Coordinates use an 860 x 480 logical
canvas; minimum height is 60. The editor canvas shows the animated GIF
with the warning text over it.
Choose a contrasting warning text colour and avoid overlapping alerts.

To show ONLY the GIF (no coloured banner, no text), tick the
"GIF only (hide text/banner)" box in that alert's row. The editor preview
then shows just the GIF with a dashed outline. If the GIF ever fails to load
on the dash, the normal coloured banner and text come back automatically so
the alarm is never invisible. Leave it unticked to keep text over the GIF.

Click Save / apply. Save As your test map, then apply/upload its resources.
Reboot the emulator or reopen the desktop renderer to reload configuration.
Existing alarm activation, priority, acknowledgement, clearing and LED logic
are not replaced.

The emulator now shows exactly what NSP shows. While the test NSP is open,
the start-stock-renderer window copies NSP's own live dash data (including its
Simulate panel) into the emulator's real renderer. Raise an alarm in NSP
(e.g. Simulate a channel past its alarm threshold): the same popup, stacking,
GIF placement and GIF-only setting appear in the emulator, and clear when NSP
clears it. The renderer console prints "Live channels and alarms now follow
NSP Simulate". Without NSP running it falls back to emulator memory, where
no alarms trigger. For a quick check without NSP, click the workbench
"Preview Alert" toolbar button after uploading. It lists the uploaded alert
texts; choose one and click OK. (Equivalent terminal command inside
`ic7-emulator`: `.\.venv\Scripts\python.exe .\native_view.py --preview-alert "TEXT"`.)
This window is explicitly labelled SYNTHETIC ALERT PREVIEW.
It tests uploaded GIF resources and rectangle configuration, not thresholds
or acknowledgement. Repeat --preview-alert to display multiple alerts.
Restart this preview after changing resources/configuration.

Test Stock background and Remove override, saving/applying each time.
The first keeps your rectangle with a stock background; removal restores
normal bottom-stacked placement. Alert GIFs are supported; MP4 alert banners
are not. MP4 remains available for screen elements and startup.

## 6. Place normal screen GIF/MP4 elements

Use NSP's existing image component on the desired screen. Choose GIF/MP4 from
the image library, then drag/resize on the screen canvas or change its X/Y
and size settings. Save the map and apply/upload. These are existing
per-screen layout settings, not the global alert overlay rectangles.

## 7. Check regressions and keep physical tests separate

Open the channel selector and affected configuration panels: resourcefix is
included. Check gauges, screen switching and ordinary media after startup.
Retain screenshots and full terminal output for any failure.

The matching physical candidate is:
`NSP-test-kit\firmware\ic7-2.36-native-media-alerts-experimental.nex`.
Do not flash merely to test the Windows resourcefix or synthetic preview.
The emulator's NEX sandbox checks transfers/resources; it does not prove a
physical installation or recovery path. Physical testing requires a separate
backup/recovery plan, stable bench power, and deliberate authorization.
Never bench-test alarms or flash while driving.

## Verification and further instructions

The original supplied map is byte-identical. All 28 resourcefix embedded
resources are retained. The NEX changes three QML members, adds one, preserves
336 others, and leaves app/kernel/bootloader unchanged.

Local tests: 99 emulator tests with real PyQt5, 24 Python/.NET regressions,
37 desktop QML checks, 33 firmware ARM/QEMU QML checks, and browser tests.
Actual Windows Forms interaction and physical alarm/boot validation remain
outstanding; passing Linux checks is not hardware certification.

See `NSP-test-kit\README.md`, `NSP-test-kit\SPLASH-TEST.md`, and
`ic7-emulator\README.md` for detailed caveats and troubleshooting.
`SHA256SUMS` records every file in this combined kit; the NSP sub-kit also
retains its own original manifest/checksums.
