import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import zipfile
import zlib


PIPE_NAME = "SIM_Dash_Pipe"


def pe_machine(path):
    try:
        with Path(path).open("rb") as stream:
            dos_header = stream.read(64)
            if len(dos_header) < 64 or dos_header[:2] != b"MZ":
                return None
            pe_offset = struct.unpack_from("<I", dos_header, 0x3C)[0]
            stream.seek(pe_offset)
            header = stream.read(6)
            if len(header) != 6 or header[:4] != b"PE\0\0":
                return None
            return struct.unpack_from("<H", header, 4)[0]
    except OSError:
        return None


def stage_windows_platform_plugin(runtime, destination):
    runtime = Path(runtime)
    destination = Path(destination)
    renderer_machine = pe_machine(runtime / "dash_virtual.exe")
    if renderer_machine is None:
        raise ValueError("Cannot determine the NSP renderer's Windows architecture")
    plugin_roots = (runtime, runtime.parent / "plugins")
    candidates = sorted(path for root in plugin_roots if root.is_dir()
                        for path in root.rglob("qwindows.dll"))
    matching = [path for path in candidates if pe_machine(path) == renderer_machine]
    if not matching:
        raise FileNotFoundError(
            "No architecture-matched qwindows.dll was found under "
            f"{runtime} or {runtime.parent / 'plugins'}; point -Runtime at the installed NSP Qt runtime"
        )
    target = destination / "platforms" / "qwindows.dll"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(matching[0], target)
    return target


def pipe_message(address, payload):
    body = struct.pack(">B3xII", 1, address, len(payload)) + payload
    return body + struct.pack(">I", zlib.crc32(body))


def validate_ack(payload):
    if len(payload) != 16 or zlib.crc32(payload[:12]) != int.from_bytes(payload[12:], "big"):
        raise ValueError("Stock renderer acknowledgement CRC or length failed")
    if payload[0] & 0x80:
        raise ValueError("Stock renderer rejected update")


def renderer_ready(display):
    return display.get("phase") in ("dash", "splash")


def renderer_restart_required(display, launched_reboot_revision):
    return (display.get("phase") == "blank" or
            display.get("reboot_revision") != launched_reboot_revision)


class WindowsPipe:
    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("The original Windows dash renderer must run on Windows")
        self.api = ctypes.WinDLL("kernel32", use_last_error=True)
        self.api.CreateNamedPipeW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                              wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                              wintypes.DWORD, wintypes.LPVOID]
        self.api.CreateNamedPipeW.restype = wintypes.HANDLE
        self.api.ConnectNamedPipe.argtypes = [wintypes.HANDLE, wintypes.LPVOID]
        self.api.ConnectNamedPipe.restype = wintypes.BOOL
        self.api.WriteFile.argtypes = [wintypes.HANDLE, wintypes.LPCVOID, wintypes.DWORD,
                                       ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID]
        self.api.ReadFile.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD,
                                      ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID]
        self.api.PeekNamedPipe.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD,
                                           wintypes.LPVOID, ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID]
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.handle = self.api.CreateNamedPipeW("\\\\.\\pipe\\" + PIPE_NAME, 3, 8, 1, 65536, 65536, 1000, None)
        if self.handle == wintypes.HANDLE(-1).value:
            raise ctypes.WinError(ctypes.get_last_error())

    def connect(self, timeout=10):
        result = []
        def accept():
            accepted = self.api.ConnectNamedPipe(self.handle, None)
            result.append(bool(accepted) or ctypes.get_last_error() == 535)
        worker = threading.Thread(target=accept, daemon=True)
        worker.start()
        worker.join(timeout)
        if worker.is_alive() or not result or not result[0]:
            raise TimeoutError("The stock renderer did not connect to its private named pipe")

    def update(self, address, payload):
        packet = pipe_message(address, payload)
        written = wintypes.DWORD()
        if not self.api.WriteFile(self.handle, packet, len(packet), ctypes.byref(written), None) or written.value != len(packet):
            raise ctypes.WinError(ctypes.get_last_error())
        received = bytearray()
        deadline = time.monotonic() + 2
        while len(received) < 16:
            available = wintypes.DWORD()
            if not self.api.PeekNamedPipe(self.handle, None, 0, None, ctypes.byref(available), None):
                raise ctypes.WinError(ctypes.get_last_error())
            if available.value:
                size = min(16 - len(received), available.value)
                buffer = ctypes.create_string_buffer(size)
                count = wintypes.DWORD()
                if not self.api.ReadFile(self.handle, buffer, size, ctypes.byref(count), None):
                    raise ctypes.WinError(ctypes.get_last_error())
                received.extend(buffer.raw[:count.value])
            elif time.monotonic() >= deadline:
                raise TimeoutError("Stock renderer update acknowledgement timed out")
            else:
                time.sleep(0.002)
        validate_ack(bytes(received))

    def close(self):
        self.api.CloseHandle(self.handle)


def get(base, path):
    attempts = 4
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(base + path, timeout=5) as response:
                return response.read()
        except urllib.error.HTTPError:
            raise
        except (urllib.error.URLError, ConnectionError, TimeoutError) as error:
            if attempt + 1 == attempts:
                raise ConnectionError(
                    f"Emulator viewer {base} unavailable at {path}; keep the emulator running"
                ) from error
            time.sleep(0.2 * (2 ** attempt))
    raise ConnectionError(f"Emulator viewer {base} unavailable at {path}")


def prepare_runtime(runtime, destination, patched):
    destination.mkdir(parents=True, exist_ok=True)
    original = runtime / "dash_virtual.exe"
    binary = original.read_bytes()
    expected = "5a5d74fe029178398512a5622d480fed213f4fd8f58e70b85ca169bb5a62303b"
    if hashlib.sha256(binary).hexdigest() != expected:
        raise ValueError("Installed renderer differs from the verified NSP 1.48.5 baseline")
    needle = b"NSP_Dash_Pipe"
    if binary.count(needle) != 1 or len(PIPE_NAME.encode()) != len(needle):
        raise ValueError("Expected exactly one compatible pipe-name literal")
    executable = destination / "ic7_dash_renderer.exe"
    isolated = binary.replace(needle, PIPE_NAME.encode(), 1)
    isolated = isolated.replace("dash_virtual".encode("utf-16le"), "ic7_sim_view".encode("utf-16le"))
    executable.write_bytes(isolated)
    for library in runtime.glob("*.dll"):
        target = destination / library.name
        if not target.exists() or target.stat().st_size != library.stat().st_size:
            shutil.copy2(library, target)
    if (runtime / "qt.conf").exists():
        shutil.copy2(runtime / "qt.conf", destination / "qt.conf")
    for name in ("platforms", "imageformats", "bearer", "styles", "qml", "plugins"):
        if (runtime / name).is_dir():
            shutil.copytree(runtime / name, destination / name, dirs_exist_ok=True)
    stage_multimedia_addons(runtime, destination)
    stage_windows_platform_plugin(runtime, destination)
    resource_archive = Path(__file__).with_name("renderer-resources.zip")
    with zipfile.ZipFile(resource_archive) as archive:
        for entry in archive.infolist():
            relative = Path(entry.filename)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Invalid renderer resource path")
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(entry))
    install_startup_qml(destination)
    if patched:
        install_component_override(destination, Path(__file__).with_name("qml") / "patched-gif" / "HalImage.qml")
    validate_multimedia_runtime(destination)
    return executable


def stage_multimedia_addons(runtime, destination):
    for source_name, target_name in (("ic7-media-qml", "qml"),
                                     ("ic7-media-plugins", "plugins")):
        source = Path(runtime) / source_name
        if source.is_dir():
            shutil.copytree(source, Path(destination) / target_name, dirs_exist_ok=True)


def install_startup_qml(destination):
    destination = Path(destination)
    sources = {
        destination / "qml_components_data/qml/factory_screens/main.qml":
            Path(__file__).with_name("qml") / "stock_renderer" / "main.qml",
        destination / "qml_components_data/qml/user_components/HalSplash.qml":
            Path(__file__).with_name("qml") / "stock_renderer" / "HalSplash.qml",
        destination / "qml_components_data/qml/user_components/HalImage.qml":
            Path(__file__).with_name("qml") / "stock_renderer" / "HalImage.qml",
    }
    for target, source in sources.items():
        if not source.is_file() or not target.parent.is_dir():
            raise FileNotFoundError(f"Stock renderer startup QML is missing: {source if not source.is_file() else target.parent}")
        shutil.copyfile(source, target)
        target.with_suffix(target.suffix + "c").unlink(missing_ok=True)
    return tuple(sources)


def validate_multimedia_runtime(destination):
    destination = Path(destination)
    required = (
        ("qml/QtMultimedia/qmldir", "QtMultimedia QML module"),
        ("qml/QtMultimedia/declarative_multimedia.dll", "QtMultimedia QML plugin"),
        ("Qt5Multimedia.dll", "QtMultimedia runtime"),
        ("Qt5MultimediaQuick.dll", "QtMultimedia Quick runtime"),
        ("Qt5Widgets.dll", "Qt Widgets runtime"),
    )
    missing = [label for relative, label in required if not (destination / relative).is_file()]
    image_plugin_paths = (destination / "plugins/imageformats", destination / "imageformats")
    if not any((folder / "qgif.dll").is_file() or (folder / "libqgif.dll").is_file()
               for folder in image_plugin_paths):
        missing.append("Qt GIF image-format plugin (imageformats/qgif.dll)")
    media_plugins = destination / "plugins/mediaservice"
    if not (media_plugins / "dsengine.dll").is_file():
        missing.append("Qt Multimedia DirectShow media-player plugin (dsengine.dll)")
    if missing:
        raise RuntimeError(
            "The isolated NSP renderer cannot load the maintained GIF/MP4 splash QML; "
            "the Qt 5.11 Multimedia runtime is incomplete: " + ", ".join(missing) +
            ". Run the combined NSP bundle's setup-native-media.ps1, open an iC-7 map "
            "in that NSP copy to stage its runtime, close its renderer, then retry."
        )
    return True


def sync_resources(base, destination, previous):
    state = json.loads(get(base, "/api/status"))
    current = {}
    for resource in state["assets"]:
        name = resource["name"]
        namespace, separator, relative_name = name.partition("/")
        if not separator or namespace not in ("h", "u") or not relative_name:
            continue
        key = (resource["kind"], name)
        current[key] = resource["sha256"]
        if previous.get(key) == resource["sha256"]:
            continue
        target = _resource_target(destination, resource["kind"], namespace, relative_name)
        target.parent.mkdir(parents=True, exist_ok=True)
        encoded = urllib.parse.urlencode({"kind": resource["kind"], "name": name})
        target.write_bytes(get(base, "/api/resource?" + encoded))
    for kind, name in previous.keys() - current.keys():
        namespace, separator, relative_name = name.partition("/")
        if not separator or namespace not in ("h", "u") or not relative_name:
            continue
        target = _resource_target(destination, kind, namespace, relative_name)
        if namespace == "h":
            archive_name = target.relative_to(destination).as_posix()
            with zipfile.ZipFile(Path(__file__).with_name("renderer-resources.zip")) as archive:
                if archive_name in archive.namelist():
                    target.write_bytes(archive.read(archive_name))
                    continue
        target.unlink(missing_ok=True)
    return current


def _resource_target(destination, kind, namespace, relative_name):
    folder = "images" if kind == 0 else "fonts"
    base_folder = "user_resources" if namespace == "u" else "qml_components_data"
    return Path(destination) / base_folder / folder / relative_name


def install_component_override(destination, component):
    source = Path(component)
    if source.name != "HalImage.qml" or not source.is_file():
        raise ValueError("Component override must be an existing HalImage.qml")
    if b"import QtMultimedia" in source.read_bytes() and not (destination / "qml/QtMultimedia/qmldir").is_file():
        raise RuntimeError("The isolated NSP preview runtime lacks the QtMultimedia QML module")
    target = destination / "qml_components_data/qml/user_components/HalImage.qml"
    if not target.is_file():
        raise FileNotFoundError("Isolated renderer's HalImage.qml is missing")
    shutil.copyfile(source, target)
    return target


def install_sandbox_component(base, destination):
    changes = json.loads(get(base, "/api/changes?after=-1"))
    checksum = changes.get("component_sha256")
    if checksum is None:
        return None
    payload = get(base, "/api/component")
    if hashlib.sha256(payload).hexdigest() != checksum:
        raise ValueError("Sandbox component response hash mismatch")
    candidate = destination / "sandbox-component" / "HalImage.qml"
    candidate.parent.mkdir(parents=True, exist_ok=True)
    candidate.write_bytes(payload)
    install_component_override(destination, candidate)
    return checksum


def renderer_environment(work):
    work = Path(work)
    platform_dirs = (work / "platforms", work / "plugins" / "platforms")
    platform_dir = next((path for path in platform_dirs if (path / "qwindows.dll").is_file()), None)
    if platform_dir is None:
        raise FileNotFoundError("The isolated Qt runtime has no qwindows.dll platform plugin")
    environment = os.environ.copy()
    environment["QT_PLUGIN_PATH"] = os.pathsep.join((str(work / "plugins"), str(work)))
    environment["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(platform_dir)
    environment["QML2_IMPORT_PATH"] = str(work / "qml")
    return environment


def main():
    parser = argparse.ArgumentParser(description="Drive an isolated original NSP dash renderer from emulator memory.")
    parser.add_argument("--url", default="http://127.0.0.1:8765")
    parser.add_argument("--runtime", type=Path, default=Path(os.environ.get("APPDATA", ".")) / "Haltech/Nexus")
    parser.add_argument("--work", type=Path, default=Path(__file__).with_name("state") / "stock-renderer")
    parser.add_argument("--patched-images", action="store_true")
    parser.add_argument("--component", type=Path, help="HalImage.qml to load in the isolated renderer")
    args = parser.parse_args()
    if os.name != "nt":
        raise SystemExit("Run the original renderer bridge on Windows")
    base = args.url.rstrip("/")
    if args.patched_images and args.component:
        parser.error("Use either --patched-images or --component, not both")
    executable = prepare_runtime(args.runtime, args.work, args.patched_images)
    if args.component:
        install_component_override(args.work, args.component)
    explicit_component = args.component is not None or args.patched_images
    component_checksum = None if explicit_component else install_sandbox_component(base, args.work)
    resources = {}
    pipe = None
    process = None
    launched_reboot_revision = None
    revision = -1
    resource_revision = None
    last_channels = 0
    try:
        while True:
            if process is not None and process.poll() is not None:
                break
            status = json.loads(get(base, "/api/status"))
            display = status.get("display", {"phase": "blank", "reboot_revision": 0})
            if process is not None and renderer_restart_required(display, launched_reboot_revision):
                print("Stopping the isolated renderer for the emulator display lifecycle change.", flush=True)
                pipe.close()
                pipe = None
                if process.poll() is None:
                    process.terminate()
                    process.wait(timeout=5)
                process = None
                revision = -1
                resource_revision = None
                last_channels = 0
                if display["phase"] == "blank":
                    time.sleep(0.05)
                    continue
            if process is None:
                if not renderer_ready(display):
                    time.sleep(0.05)
                    continue
                resources = sync_resources(base, args.work, resources)
                pipe = WindowsPipe()
                process = subprocess.Popen(
                    [str(executable.resolve()), "./qml_components_data/qml", "54000", "21", "11"],
                    cwd=args.work, env=renderer_environment(args.work))
                try:
                    pipe.connect()
                except Exception:
                    pipe.close()
                    pipe = None
                    if process.poll() is None:
                        process.terminate()
                        process.wait(timeout=5)
                    process = None
                    raise
                launched_reboot_revision = display["reboot_revision"]
                revision = -1
                resource_revision = None
                last_channels = 0
                print("Original dash renderer connected to isolated SIM_Dash_Pipe.", flush=True)
                continue
            changes = json.loads(get(base, f"/api/changes?after={revision}"))
            if not explicit_component and changes.get("component_sha256") != component_checksum:
                print("Sandbox component changed. Restart the renderer to reload its QML.", flush=True)
                break
            resources_changed = changes["resource_revision"] != resource_revision
            if resources_changed:
                resources = sync_resources(base, args.work, resources)
                resource_revision = changes["resource_revision"]
            if changes["full_refresh"]:
                ranges = [{"address": 0x20000, "length": 651264}]
            else:
                ranges = changes["ranges"]
            for entry in ranges:
                for offset in range(0, entry["length"], 16384):
                    count = min(16384, entry["length"] - offset)
                    address = entry["address"] + offset
                    payload = get(base, f"/api/memory?address={address}&length={count}")
                    pipe.update(address, payload)
            revision = changes["revision"]
            if ranges or resources_changed:
                pipe.update(0, b"\0\x17")
            if time.monotonic() - last_channels >= 0.1:
                for offset in (0, 16384):
                    payload = get(base, f"/api/memory?address={0x1400 + offset}&length=16384")
                    pipe.update(0x1400 + offset, payload)
                last_channels = time.monotonic()
            time.sleep(0.02)
    except KeyboardInterrupt:
        pass
    finally:
        if pipe is not None:
            pipe.close()
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


if __name__ == "__main__":
    main()