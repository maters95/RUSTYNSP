# iC-7 NSP Simulator

Runnable protocol simulator built from the owner's iC-7 v2.36 USB captures,
definition, stock resources and matching NSP 1.48.5 source.

**The owner has now connected Windows NSP through HHD COM10/COM11.** The
log confirms identity, full settings reads and sustained channel polling.
The original Windows renderer bridge has not been validated on Windows.
This is a runnable test build, not a
claim of complete hardware or firmware emulation. Keep the physical dash
disconnected while testing virtual ports.

## Windows Setup

1. Extract the complete simulator ZIP to a normal writable folder.
2. Install Python 3.11 or newer from python.org if it is not already installed.
3. For an immediate viewer-only check, run:

   ```powershell
   .\start-emulator.cmd -ViewerOnly
   ```

   The launcher creates a private Python environment, installs dependencies,
   and opens `http://127.0.0.1:8765`. Initial setup requires internet access.
   Leave its terminal open. No virtual-port driver is needed for viewer-only mode.

4. To connect NSP, install a **signed virtual null-modem/serial-port driver**
   using its normal vendor installer. HHD Virtual Serial Ports is one example;
   a correctly signed com0com installation is another. No kernel driver is
   bundled, and disabling Windows driver-signing enforcement is not required
   or recommended. Create a paired connection, for example **COM10 <-> COM11**.
5. With the real dash disconnected, run this once in an administrator PowerShell:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\set-nsp-port.ps1 -Port COM10
   ```

   NSP's source only scans ports whose description contains `Haltech`. The
   helper changes the selected virtual port's device description to
   `Haltech iC-7 Simulator`, saves the old description locally, and rejects
   physical USB ports. This SetupAPI operation is compiled but not exercised
   on Windows here; some drivers may reject it. Stop on errors rather than
   relabelling the real dash. `-ListOnly` reads the current description.
6. Stop viewer-only mode with Ctrl+C, then start the protocol simulator:

   ```powershell
   .\start-emulator.cmd -Port COM11
   ```

7. Open/restart NSP. NSP should discover the **COM10** end, while the simulator
   owns **COM11**. Do not configure both applications to open the same port.
   The simulated serial is `F1C700000001`; it is intentionally not the real dash.
8. In another terminal, start the original-renderer bridge:

   ```powershell
   .\start-stock-renderer.cmd
   ```

   This uses the verified `dash_virtual.exe` and 32-bit Qt runtime already
   installed at `%APPDATA%\Haltech\Nexus`. If your path differs, pass
   `-Runtime 'C:\path\to\Haltech\Nexus'`.

The driver installation and port-description change are Windows-local setup
steps; this container cannot install or verify them on your PC. If NSP does
not connect, return `state\emulator.log` and the port-helper output. If there
is no protocol traffic, diagnose discovery/port pairing before changing maps.

## Live Update Behavior

The protocol emulator acknowledges writes, changes its own memory immediately,
and provides read-back from that updated memory. Settings writes and completed
resource updates have revision counters. Unknown memory reads are logged and
return zeroes; this fallback is not a claim that every device service is modeled.

Resource RPC writes return their results inline, rather than a plain write
acknowledgement followed by a separate read. The initial Windows test exposed
this defect as repeated resource queries with roughly 1.5-second pauses.
The corrected resource-count reply has 19 bytes (header, 3-byte result, CRC),
matching NSP source and the physical capture. This correction passed local
regression tests; its Windows retest is pending.

The **original renderer bridge** follows the matching source:

- `NSP.UserInterface/VirtualDashAppPanel.cs` launches the actual preview program.
- `c/CB.cs`, class `cb`, sends individual setting bytes or complete settings
  buffers to their memory addresses and forwards the channel buffer.
- `c/CC.cs`, class `cC`, implements the named-pipe framing and acknowledgement.
- Each IPC message is command 1, three zero bytes, a big-endian 32-bit address,
  big-endian length, data and standard big-endian CRC-32.
- The bridge polls changed address ranges at 20 ms intervals, forwards exact
  bytes, and sends the source-confirmed refresh command after updates.
- The stock channel buffer is forwarded every 100 ms. Sensor data is captured,
  not a live CAN/GPS simulation; no plausible-looking readings are fabricated.
- Completed user resources are copied before setting references are forwarded.

A private copy of the renderer and its resources is created under
`state\stock-renderer`. Its pipe name is isolated as `SIM_Dash_Pipe`, and its
window name is isolated too. Installed NSP files are never changed. The private
copy's cryptographic executable signature, if present, is no longer valid
after these same-length namespace substitutions; this is not bypassing Windows
signing policy. Antivirus may flag modified executables. Do not disable it;
report the error and use the fallback viewer while investigating.

To compare the GIF candidate in this **private renderer only**:

```powershell
.\start-stock-renderer.cmd -PatchedImages
```

This selects the candidate `HalImage.qml` in the isolated runtime. It does not
flash firmware or install a QML patch on real hardware.

## Viewer Modes

The browser displays live traffic, received 800x480 BMPs, asset previews, and
an **approximate** settings-driven layout. Its numeric placeholders are not
the original renderer and must not be mistaken for real sensor readings.

An optional native fallback uses individual stock QML components with a
partial property mapping:

```powershell
.\.venv\Scripts\python.exe .\native_view.py
```

The original-renderer bridge is the fidelity target; the fallback reports
unavailable sensor values and unsupported component types explicitly.

## Persistence and Boundaries

- State, resource files, staged writes and logs live under `state/`.
- Ctrl+C saves mutable memory. Restart with the same state directory to retain it.
- For a clean session, stop the simulator and move `state/` aside.
- Protocol reboot/control commands are logged, not fully modeled as USB
  disconnect/re-enumeration or a real bootloader cycle.
- Firmware writes are staged locally. They do not execute firmware, implement
  A/B flash updates, prove package installation, or validate physical recovery.
- The original renderer's full Windows connection/startup and long-running
  NSP edit behavior remain unverified until tested on the owner's PC.
- The profile includes private vehicle assets/configuration from the captures.
  Do not publish it without reviewing its contents.

Restore the virtual-port description when finished, in administrator PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\set-nsp-port.ps1 -Port COM10 -Restore
```

## Verification

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s .\tests -v
```

Local checks cover CRC rejection, fragmented/coalesced requests, write/read-back,
identity, persistence, image/font resource operations, resource checksum rejection,
uploaded BMP display, live setting writes changing scene/pixels, and the
source-derived original-renderer pipe contract. Desktop/mobile browser checks
and a fallback Qt screenshot also passed. Passing these does not establish an
NSP connection or a physical-dash match.

The optional `--tcp 127.0.0.1:54001` transport is for protocol test clients,
not an NSP network-discovery endpoint. NSP connectivity uses the virtual COM pair.