import hashlib
import json
from pathlib import Path
import zipfile


def main():
    root = Path(__file__).resolve().parent
    destination = root.parent / "dist" / "ic7-emulator-windows.zip"
    destination.parent.mkdir(exist_ok=True)
    included = []
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for source in sorted(root.rglob("*")):
            relative = source.relative_to(root)
            if not source.is_file() or any(part in ("__pycache__", "state", ".venv") for part in relative.parts):
                continue
            if source.name.startswith("port-") or source.suffix in (".pyc", ".jsc", ".qmlc"):
                continue
            archive.write(source, "ic7-emulator/" + relative.as_posix())
            included.append(relative.as_posix())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("Distribution integrity check failed")
    report = {"file": destination.name, "bytes": destination.stat().st_size,
              "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "files": len(included),
              "status": "Windows NSP basic serial session observed; resource RPC fix locally tested; original renderer Windows runtime unverified"}
    destination.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()