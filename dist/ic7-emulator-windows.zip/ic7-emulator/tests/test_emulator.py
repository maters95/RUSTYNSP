import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock
import urllib.request
import zipfile
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ic7_emulator import Device, Memory, RequestStream, Resources, request, resource_descriptor
from ic7_emulator import serve_stream
from viewer import start_viewer, render_layout, scene_state
from stock_renderer import pipe_message, validate_ack


class ProtocolTests(unittest.TestCase):
    def test_original_preview_pipe_contract(self):
        packet = pipe_message(0x20000, b"test")
        self.assertEqual(packet[:12], bytes.fromhex("010000000002000000000004"))
        self.assertEqual(packet[12:-4], b"test")
        acknowledgement = packet[:12] + zlib.crc32(packet[:12]).to_bytes(4, "big")
        validate_ack(acknowledgement)
        with self.assertRaises(ValueError):
            validate_ack(acknowledgement[:-1] + bytes((acknowledgement[-1] ^ 1,)))

    def test_fragmented_and_coalesced_requests(self):
        first = request(2, 7, 0x1400, 13312)
        second = request(1, 8, 0x20000, 4, b"test")
        stream = RequestStream()
        self.assertEqual(stream.feed(first[:9]), [])
        self.assertEqual(stream.feed(first[9:] + second), [first, second])

    def test_rejects_bad_crc(self):
        packet = bytearray(request(2, 7, 0, 1024))
        packet[-1] ^= 1
        stream = RequestStream()
        self.assertEqual(stream.feed(packet), [])
        self.assertGreater(stream.rejected, 0)

    def test_memory_crosses_page_boundary(self):
        memory = Memory()
        memory.write(4094, b"abcdef")
        self.assertEqual(memory.read(4092, 10), b"\0\0abcdef\0\0")

    def test_device_ack_and_readback(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            profile = root / "profile.zip"
            with zipfile.ZipFile(profile, "w") as archive:
                archive.writestr("profile.json", json.dumps({"segments": [{"address": 0, "file": "id.bin"}]}))
                archive.writestr("id.bin", bytes((2, 36, 0)) + bytes(1021))
            device = Device(profile, root / "state")
            write = request(1, 3, 0x20000, 4, b"test")
            ack = device.respond(write)
            self.assertEqual(ack[:12], write[:12])
            self.assertEqual(len(ack), 16)
            read = request(2, 4, 0x20000, 4)
            reply = device.respond(read)
            self.assertEqual(reply[:12], read[:12])
            self.assertEqual(reply[12:-4], b"test")
            self.assertEqual(zlib.crc32(reply[:-4]), int.from_bytes(reply[-4:], "big"))
            device.respond(request(1, 5, 0, 2, b"\0\1"))
            self.assertEqual(device.memory.read(0, 3), bytes((2, 36, 0)))
            device.save()
            restored = Device(profile, root / "state")
            self.assertEqual(restored.memory.read(0x20000, 4), b"test")


class ResourceTests(unittest.TestCase):
    def test_resource_roundtrip(self):
        with tempfile.TemporaryDirectory() as temporary:
            resources = Resources(temporary)
            payload = b"GIF89a-test-fixture"
            descriptor = resource_descriptor("u/probe.png", 0, payload)
            command = b"\x06\0\0\0" + descriptor + struct.pack(">I", 0) + payload
            self.assertEqual(resources.command(command), b"\0")
            self.assertEqual(resources.command(b"\x01\0"), b"\0\0\1")
            listing = resources.command(b"\x02\0\0\0\0\0")
            self.assertEqual(listing, b"\0" + descriptor)
            read = b"\x03\0\0\0" + descriptor + struct.pack(">II", 0, len(payload))
            self.assertEqual(resources.command(read), bytes(4) + payload)
            new_descriptor = resource_descriptor("u/renamed.png", 0, payload)
            self.assertEqual(resources.command(b"\x04\0\0\0" + descriptor + new_descriptor), b"\0")
            self.assertEqual(resources.command(b"\x05\0\0\0" + new_descriptor), b"\0")
            self.assertEqual(resources.command(b"\x01\0"), b"\0\0\0")

    def test_bad_resource_checksum_is_not_success(self):
        with tempfile.TemporaryDirectory() as temporary:
            resources = Resources(temporary)
            descriptor = resource_descriptor("u/probe.png", 0, b"valid")
            command = b"\x06\0\0\0" + descriptor + bytes(4) + b"wrong"
            self.assertEqual(resources.command(command), b"\x01")
            self.assertEqual(resources.items, {})

    def test_rejects_directory_escape(self):
        with tempfile.TemporaryDirectory() as temporary:
            resources = Resources(temporary)
            descriptor = resource_descriptor("../../escape", 0, b"x")
            command = b"\x06\0\0\0" + descriptor + bytes(4) + b"x"
            self.assertEqual(resources.command(command), b"\x01")
            self.assertEqual(resources.items, {})


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.device = Device(Path(__file__).resolve().parents[1] / "device-profile.zip", self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def test_real_profile_identity(self):
        response = self.device.respond(request(2, 1, 0, 1024))
        self.assertEqual(response[12:15], bytes((2, 36, 0)))
        self.assertEqual(response[20], 21)
        self.assertEqual(response[12 + 256:12 + 262], bytes.fromhex("F1C700000001"))

    def test_resource_query_returns_inline_reply_like_nsp(self):
        query = request(1, 152, 0x70000000, 2, b"\x01\0")
        response = self.device.respond(query)
        self.assertEqual(len(response), 19)
        self.assertEqual(response[:12], query[:12])
        self.assertEqual(response[12], 0)
        count = int.from_bytes(response[13:15], "big")
        self.assertEqual(count, sum(kind == 0 for kind, _ in self.device.resources.items))
        self.assertEqual(zlib.crc32(response[:-4]), int.from_bytes(response[-4:], "big"))
        listing = request(1, 153, 0x70000000, 6, b"\x02\0\0\0\0\1")
        listed = self.device.respond(listing)
        self.assertEqual(len(listed), 16 + 1 + 2 * 60)
        self.assertEqual(listed[:12], listing[:12])
        self.assertEqual(listed[12], 0)

    def test_resource_read_error_still_matches_expected_reply_length(self):
        descriptor = resource_descriptor("u/missing.png", 0, bytes(20))
        payload = b"\x03\0\0\0" + descriptor + struct.pack(">II", 0, 20)
        response = self.device.respond(request(1, 1, 0x70000000, len(payload), payload))
        self.assertEqual(len(response), 16 + 4 + 20)
        self.assertEqual(response[12], 1)

    def test_cancelled_image_response_does_not_send_second_response(self):
        server = start_viewer(self.device, 0)
        try:
            for phase in ("headers", "body"):
                with self.subTest(phase=phase):
                    handler = server.RequestHandlerClass.__new__(server.RequestHandlerClass)
                    handler.path = "/layout.png?screen=0"
                    handler.send_response = Mock()
                    handler.send_header = Mock()
                    handler.end_headers = Mock()
                    handler.wfile = Mock()
                    failure = ConnectionAbortedError(10053, "Browser cancelled request")
                    if phase == "headers":
                        handler.end_headers.side_effect = failure
                    else:
                        handler.wfile.write.side_effect = failure
                    handler.do_GET()
                    handler.send_response.assert_called_once_with(200)
                    self.assertTrue(handler.close_connection)
        finally:
            server.shutdown()
            server.server_close()

    def test_invalid_image_request_still_returns_error(self):
        server = start_viewer(self.device, 0)
        try:
            handler = server.RequestHandlerClass.__new__(server.RequestHandlerClass)
            handler.path = "/layout.png?screen=invalid"
            handler.send = Mock()
            handler.do_GET()
            handler.send.assert_called_once_with(b"Invalid image request", "text/plain", 400)
        finally:
            server.shutdown()
            server.server_close()

    def test_uploaded_bitmap_reaches_viewer(self):
        from PIL import Image
        image = Image.new("RGB", (800, 480), (26, 140, 80))
        encoded = io.BytesIO()
        image.save(encoded, format="BMP")
        payload = encoded.getvalue()
        for offset in range(0, len(payload), 4096):
            fragment = payload[offset:offset + 4096]
            self.device.respond(request(1, offset // 4096 % 256, 0x70400000 + offset, len(fragment), fragment))
        self.assertEqual(self.device.last_screen, payload)
        server = start_viewer(self.device, 0)
        try:
            base = f"http://127.0.0.1:{server.server_port}"
            with Image.open(io.BytesIO(urllib.request.urlopen(base + "/received.png").read())) as received:
                self.assertEqual(received.size, (800, 480))
                self.assertEqual(received.getpixel((100, 100)), (26, 140, 80))
            status = json.load(urllib.request.urlopen(base + "/api/status"))
            self.assertTrue(status["received_screen"])
        finally:
            server.shutdown()
            server.server_close()

    def test_socket_transport_fragmentation(self):
        import socket
        server_socket, client = socket.socketpair()
        client.settimeout(3)
        worker = threading.Thread(target=lambda: serve_stream(self.device, lambda: server_socket.recv(65536), server_socket.sendall))
        worker.start()
        try:
            packet = request(2, 11, 0, 1024)
            client.sendall(packet[:5])
            client.sendall(packet[5:])
            response = bytearray()
            while len(response) < 1040:
                response.extend(client.recv(1040 - len(response)))
            self.assertEqual(response[:12], packet[:12])
            self.assertEqual(response[12:15], bytes((2, 36, 0)))
        finally:
            client.close()
            worker.join(timeout=3)
            server_socket.close()
        self.assertFalse(worker.is_alive())

    def test_protocol_settings_writes_update_scene_and_pixels(self):
        schema = json.loads((Path(__file__).resolve().parents[1] / "viewer-schema.json").read_text())
        component = next(item for item in schema["components"] if item["screen"] == 0 and item["component"] == 0)
        fields = component["fields"]
        before = render_layout(self.device, 0).tobytes()
        changes = {"GAUGE_TYPE": 2, "X_POS": 23, "Y_POS": 31, "X_SIZE": 320,
                   "Y_SIZE": 160, "DAY_OPACITY": 1000, "IMAGE_SRC": "u/ic7_static_probe.png",
                   "LABEL_TEXT": "LIVE UPDATE"}
        for sequence, (name, value) in enumerate(changes.items()):
            field = fields[name]
            payload = value.encode().ljust(field["bytes"], b"\0") if isinstance(value, str) else value.to_bytes(field["bytes"], "little", signed=field["signed"])
            self.device.respond(request(1, sequence, 0x20000 + field["address"], len(payload), payload))
        updated = scene_state(self.device, 0)
        actual = next(item["values"] for item in updated["components"] if item["index"] == 0)
        for name, value in changes.items():
            self.assertEqual(actual[name], value)
        self.assertEqual(updated["revision"][0], len(changes))
        self.assertNotEqual(before, render_layout(self.device, 0).tobytes())


if __name__ == "__main__":
    unittest.main()