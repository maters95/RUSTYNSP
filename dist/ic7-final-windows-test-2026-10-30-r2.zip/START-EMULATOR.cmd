@echo off
cd /d "%~dp0ic7-emulator"
call start-workbench.cmd %*
