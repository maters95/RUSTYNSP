@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-virtual-pair.ps1" %*
if errorlevel 1 pause
