# iC-7 v2.36 Media Resource Candidates

These are experimental resource-only NEX packages, not a full custom operating
system. They rebuild the existing media experiments; a new filename does not
establish a new or proven installation method. No physical dash was flashed.

## Packages

Paths are relative to the repository root:

- GIF-only: `ic7-custom-dash/build-cfw-gif/ic7-2.36-gif-cfw-candidate-experimental.nex`
- GIF and MP4: `ic7-custom-dash/build-cfw-media/ic7-2.36-media-cfw-candidate-experimental.nex`
- Stock resources: `ic7-custom-dash/build-cfw-media/ic7-2.36-stock-resources-experimental.nex`
- Original full vendor package: `Dash-V2-36-0-Release.nex`

Each candidate lists only `res_ic-7.qzip` for product 21, variant 11, using the
stock hardware-ID restrictions. Inside the decrypted archive, only
`qml_components_data/qml/user_components/HalImage.qml` changes. The other 338
members are unchanged. App, kernel, bootloader, definition and I/O firmware
are not included. The stock-resource package contains the original encrypted
resource payload byte for byte, but uses an experimental resource-only manifest.

## Verified Offline

- NEX ZIP integrity, encrypted-resource decode/encode round trip, archive member
  set, single-component diff, and unchanged stock wrapper fields.
- Media component: 8 passing Qt 5.9.6 ARM QML tests under QEMU, including GIF
  frame advancement and MP4 playback position advancing and pausing.
- GIF-only component: 7 passing applicable tests on the same userspace.
- GIF-only imports QtQuick without importing QtMultimedia.

QEMU does not establish physical video decode performance or boot behavior.
The wrapper's 16-byte metadata field is preserved, not independently validated
against the target updater. It is not the MD5 of the stock encrypted or plaintext
payload. There is no HalImage.qmlc cache in the stock resource archive.

## Before A Physical Attempt

1. Keep the real dash disconnected for the first NSP package-selection test.
   Attach NSP to the virtual dash, select the GIF-only candidate, and verify that
   the update queue contains only the resource file for the correct device.
   Record errors and the raw capture. Emulator acknowledgements and staged
   writes do not prove that the physical watchdog can install or recover it.
2. Establish a recovery method that works when the normal dash application does
   not start. Keep the original vendor package and a backup of the current map.
   The stock-resource NEX is not a guaranteed recovery method: NSP connectivity
   may depend on the application that a bad QML resource can prevent starting.
   Do not assume an A/B rootfs switch restores shared resources.
3. A physical attempt requires stable bench power, the exact compatible device
   and firmware, and acceptance of display/boot failure risk. Do not use a
   vehicle being driven as the test environment. No physical flash is authorized
   or performed automatically by these build scripts.
4. Prove GIF-only behavior before considering the combined media candidate.
   MP4 adds a QtMultimedia dependency. A failed import can affect every image
   component, including otherwise static images.

## Assets Are Separate

These NEX files install a renderer component, not a user map or media file.
The saved test map selects `u/ic7_animation_probe.png`, which contains GIF data.
That selection and resource descriptor were confirmed in the serial capture.
The emulator preloaded that resource, so that session did not prove upload.

The combined component recognizes `.mp4` paths and the GIF/animation-PNG paths.
NSP accepting and transferring an MP4 map asset to a physical dash remains
unverified. Do not infer MP4 installation from desktop or QEMU playback alone.