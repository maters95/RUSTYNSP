# Experimental iC-7 GIF alert banners and placement

This combined candidate retains the verified screen GIF/MP4 component, startup
splash, and all 28 embedded resources from the resourcefix bundle. Keep the
working videofix/resourcefix/splash copies and your original map unchanged.
Windows GUI operation and a physical flash/boot have **not** been performed.

## Install the matching pair

Extract the new native-integration test ZIP into a new directory and use
its setup script with the official NSP install as the source:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup-native-media.ps1 `
  -NspInstall 'C:\Program Files (x86)\Haltech\Nexus Software\Haltech NSP' `
  -Destination "$env:USERPROFILE\Downloads\NSP-native-media-alerts"
```

Use the **new DLL and new alerts NEX together**. The earlier splash NEX does
not contain the new popup component. No firmware is flashed automatically.
See the included [startup guide](SPLASH-TEST.md) for the emulator COM pair,
Qt runtime setup, GIF/MP4 splash tests and physical-validation boundary.
Qt libraries are downloaded from the pinned official archives, not redistributed.
The included map is an optional diagnostic example; use a backup of your own map
for acceptance testing. Do not mix this DLL/NEX pair into an older test bundle.

## Configure alerts in NSP

1. Disconnect the physical dash. Open a backup iC-7 v2.36 map in the new NSP.
2. Open the editor: click **Appearance...** below the Message
   setting on an alarm's page, right-click the alarm in the tree and choose
   **Appearance...**, or use **Alarm appearance...**
   from NSP's main menu. The first two preselect that alarm.
3. Opening from an alarm page/tree edits that alarm only, keeps other alarms'
   appearances intact and locks the Message column. No manual matching is needed
   in this contextual editor. The bulk menu editor still matches the exact,
   case-sensitive text received by the stock popup:
   the alarm's **Message** setting, not its tree name. If its runtime text
   differs, enter that exact text instead. Applying appearance binds a uniquely
   named alarm to its native Message setting ID, so later Message edits and
   setting undo/redo retain its appearance without manually renaming an override.
   Older manifests acquire this binding when applied in the new editor. Alarms
   with identical Message text still share an unbound text-based appearance.
4. **Choose GIF/image** opens NSP's existing image library/import picker.
   Start with the bundled `samples/animated.gif`. GIF bytes are preserved;
   static PNG/JPEG/BMP images also work. MP4 is supported on screens and at
   startup, **not in this alert-banner selector**.
5. Move the rectangle in the layout preview; drag its bottom-right corner
   to resize. Or edit **X / Y / Width / Height** numerically in the grid.
   Coordinates use the dash's **860 x 480 logical canvas**, scaled to the
   physical 800 x 480 display. Rectangles must fit and be at least 60 pixels
   tall. The editor canvas animates the GIF with the text over it; it is
   not an alarm trigger.
6. **Apply**, or **OK**, updates the map's working resources and renderer cache,
   then requests NSP's existing native preview refresh. Changed media marks the
   map modified using NSP's normal save/close prompt. **Cancel** discards unapplied
   appearance edits; images imported into the library remain there, as with the
   normal image picker. Save/Save As normally to retain the map on disk;
   no separate resource save, mandatory new filename or desktop reopen is needed.
   Editing does not silently upload to a connected physical dash: explicitly tick
   **Also upload to connected dash** when wanted. Otherwise use the normal map
   resource upload. Transfer errors are shown, not reported as success.
7. The updated popup reloads its manifest on native property/repaint/alarm updates.
   Unchanged updates retain the existing GIF instance instead of restarting its
   animation. **Stock background** keeps placement but removes the custom
   media; **Remove override**, followed by Apply, restores the
   stock bottom-stacked placement for that alert.

The integration build is in `build-cfw-native-media-alerts-integration-236`.
The original owner-confirmed videofix bundle and working `HalImage.qml` are
unchanged. This build still needs Windows acceptance testing of the actual
native refresh/renderer-pipe path. A physical dash needs the matching updated
popup and transferred resources; desktop hot reload alone does not establish
hardware hot reload or authorize flashing.

By default the GIF is the banner background and the warning text is drawn
over it. Tick **GIF only (hide text/banner)** for an alert to show only the GIF
inside its rectangle: the coloured stock banner and the text are hidden (the
editor preview shows a dashed outline). GIF only needs a GIF or image source.
If that media fails to load on the dash, the stock coloured banner and warning
text come back automatically, so an alarm is never invisible. Older manifests
without this setting keep the text. Alarm
colours, alarm activation, priority/order, clear/acknowledgement logic and
LED rules remain controlled by the original application. Choose sufficient
width and contrasting colours so the warning stays readable. Avoid overlapping
alert rectangles: overlapping alerts retain the application's model order.
The popup remains above ordinary dashboard components and below startup media.
Invalid configuration logs an error and keeps stock warning banners; a failed
GIF decoder logs an error while the warning text/background remain.

Placement applies wherever that alarm normally appears, across screen changes.
It does not suppress alerts on selected screens or create a new alarm engine.
Unconfigured alerts keep their original bottom-stacked layout; other dash
variants do not use the custom rectangle manifest.

## Place ordinary GIF/MP4 screen elements

Use the existing image component on the desired screen, choose the GIF/MP4 in
the image library, and use NSP's existing canvas drag/edge-resize controls or
component X/Y and size settings. Those settings are already per-screen and
persist in the map. This candidate reuses that editor rather than introducing
a second incompatible screen-layout format. Reserved media PNG aliases retain
the working videofix behavior. Alert banners remain overlays, not ordinary
screen components.

## Test on the Windows emulator

Use `ic7-emulator-windows-nexmap-alerts.zip` in a separate directory.
Open an iC-7 map once in the new NSP copy to stage its Qt add-ons; close its
renderer. Run `.\start-workbench.cmd`; **Dash Display** opens automatically on
Windows. Do not start a second `start-stock-renderer.cmd` alongside it.
The isolated renderer installs the exact four QML components from this NEX.
It requires the matching Qt 5.11 x86 multimedia/GIF add-ons and DirectShow
`dsengine`; missing dependencies are explicit errors. Upload map settings from
NSP: the display must remain blank until those settings arrive.

**The emulator mirrors NSP's live-data input, not its rendered frames.** While this NSP is
open, it publishes the same live-data block it sends to its own dash renderer
(read-only, local shared memory `HaltechNSP_iC7_LiveData`). The workbench's
**Dash Display** window applies that block to the original renderer,
so NSP's **Simulate** panel (or live data) can drive the matching popup
with the same map/resources. The bridge polls independently at roughly 50 ms;
it does not synchronize frames, GIF clocks or clearing instants. Exact
simultaneous NSP/emulator display remains unresolved. Its console prints
`Live channels and alarms now follow NSP Simulate` (or `NSP live data`); when
NSP stops updating for a second it falls back to emulator memory. Nothing is
written to a dash.

For a clearly labelled **synthetic alert preview** without NSP, after uploading map resources,
click **Preview Alert** in the workbench toolbar and pick an uploaded alert
text, or run:

```powershell
.\.venv\Scripts\python.exe .\native_view.py --preview-alert "OIL PRESSURE"
```

Use the exact text configured in NSP; repeat `--preview-alert` to show multiple
alerts. This exercises the shared popup and GIF/rectangle manifest over the
emulator HTTP resource API. It does **not** trigger a real threshold, modify
device settings, or validate alarm evaluation/acknowledgement. The normal stock
renderer path remains separate. Test a real alarm condition and its clearing
on the Windows renderer before any separately authorized bench test.

Repeat startup with GIF and MP4, reboot twice, then test an alert GIF, a static
alert image, an empty source, and removal of the override. Reopen the saved map
and re-upload to check persistence. Open the channel selector to verify the
resourcefix GUI fix remains present. Check ordinary screen positioning and
switch screens while alerts are active.

## Integrity and automated verification

The resource-only NEX changes only `main.qml`, `HalImage.qml` and
`HalAlarmPopup.qml`, adds `HalSplash.qml`, and preserves all **336** other
decoded stock members. Its original 44-byte wrapper and migration HDEF are
byte-identical. Application, kernel, bootloader and kernel-logo tooling are
unchanged. The earliest kernel logo remains static.

Build with `scripts/build-nsp-gif-preview.py --splash --alerts` and a new output
directory; package with `scripts/package-nsp-media-test.py --native-media
--splash --alerts`. The included map is the supplied original, byte-for-byte,
not preconfigured with new alert rules.

Checks include .NET compilation and manifest validation, stock-root/alert hash
guards and cache removal, resourcefix byte equality, decoded NEX member
equality, real desktop and firmware Qt 5.9.6 ARM GIF animation/geometry/clearing,
repeated GIF/MP4 startup, and an actual HTTP-to-QML alert preview screenshot.
These checks do not prove Windows plugin loading, hardware installation,
physical alarm behavior, or a recovery method. Retain the working NEX, back
up the map and establish recovery before any bench flash; do not test while
driving.

Verified locally: x86 DLL build with zero compiler errors (402 existing
decompilation warnings); **24** Python/.NET regressions; **37** desktop QML
checks; **33** firmware ARM/QEMU QML checks; **110** emulator Python tests with
real PyQt5; and browser checks. ZIP hashes and all packaged QML bytes are
checked against the tested sources. Windows Forms editor interaction remains
an on-PC validation step, not a result of the Linux cross-build.
