# Safely running ic7dash on the dash — WITHOUT flashing (reversible)

This is how you confirm the app runs on your actual iC-7 with **zero risk of
bricking**: it never writes to firmware. You copy the binary to the dash's
writable scratch area, run it by hand, watch it, then restart the stock dash (or
just power-cycle). Nothing in firmware changes, so the worst case is "it didn't
run, power-cycle, you're back to normal."

Do the permanent-install route (DEPLOY.md, flashing a partition) ONLY after this
reversible test succeeds.

## Why this is safe
- Writes only to `/mnt/usb` (eMMC partition p4, scratch) — never p1/p2 (the A/B
  firmware) or `/opt` (the stock app). Nothing in the boot chain is touched.
- Recovery from anything is just a power-cycle: the dash boots the untouched
  stock firmware.
- The app only owns the screen and reads CAN/GPS; its only writes are map tiles
  cache under `/mnt/usb`.

## Prerequisites (confirm on YOUR unit first)
1. **An ARM build of ic7dash** — cross-compiled per `CROSS-BUILD.md` on a Linux
   box. (It could not be built on the Windows analysis PC; that's expected.)
2. **A shell on the dash.** The firmware image contains dropbear (SSH). You need
   it reachable and your own credentials for it. If SSH is not enabled/known on
   your unit, DO NOT try to bypass it — ask Haltech/Ingenuity for the developer
   access path. Without a shell (SSH or serial console) this method can't be used.
3. **Network to the dash** — e.g. its Wi-Fi (the firmware can bring up `wlan0`)
   or Ethernet. Confirm you can `ssh` in.
4. The other NSP session isn't actively using the dash while you test.

## Steps
```sh
# 1. From your Linux build box, copy the app bundle to the dash's scratch area.
#    (replace dash-ip / user with yours)
scp -r build-arm/ic7dash emtron_can.json tiles deploy/bringup-can.sh \
    root@dash-ip:/mnt/usb/ic7test/

# 2. SSH in
ssh root@dash-ip

# 3. On the dash: stop the stock UI + its watchdog so they release the screen.
systemctl stop watchdog-launcher gui-launcher

# 4. Run the app on the framebuffer. CAN is optional — if can0 isn't up the app
#    falls back to a simulated feed, so the UI still comes up.
cd /mnt/usb/ic7test
chmod +x ic7dash bringup-can.sh
./bringup-can.sh can0 1000000        # optional: only if you've wired CAN
QT_QPA_PLATFORM=eglfs \
QT_NMEA_SERIAL_PORT=/dev/ttyUSB0 \
IC7_CAN=can0 \
./ic7dash
# -> you should see the gauges page; swipe/second screen shows the map + laps.

# 5. Stop and restore the stock dash:
#    Ctrl-C to quit the app, then:
systemctl start gui-launcher watchdog-launcher
#    (or just power-cycle the dash — nothing was changed.)
```

## If something's off (all harmless)
- **App errors on eglfs** (`Failed to create...`): the board may need a specific
  integration. Check what the stock app used: `systemctl cat gui-launcher` and
  match its `QT_QPA_*` environment, then re-run step 4 with those.
- **Screen stays black / app exits**: read the error it printed; missing Qt
  plugins mean the ARM build can't find them — fix on the build side,
  re-copy, retry. Firmware is still untouched.
- **Watchdog reboots the dash** when you stop gui-launcher: harmless — it boots
  the stock firmware. If it's disruptive, stop `watchdog-launcher` first (step 3
  already does).
- **No CAN data**: expected if `can0` isn't wired/up — the app shows the
  simulated feed. Wire CAN and re-run to see live values.

## What this proves
That the app actually runs on *your* hardware, with your Qt/eglfs, and reads your
CAN — before any firmware change. Once this is solid, `DEPLOY.md` covers making
it permanent safely (flash the PASSIVE partition, keep the good one, verify i.MX6
USB recovery first). Leave the STM32 I/O firmware alone throughout.
```
